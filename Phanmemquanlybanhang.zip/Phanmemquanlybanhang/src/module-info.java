/**
 * 
 */
/**
 * 
 */
module Phanmemquanlybanhang {
	requires java.desktop;
}