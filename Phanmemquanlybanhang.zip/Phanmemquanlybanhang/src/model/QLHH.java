//package model;
////import java.sql.Connection;
//import java.sql.DriverManager;
//
//public class QLHH {
//	    public static Connection getConnection() {
//	        Connection conn = null;
//	        try {
//	            Class.forName("com.mysql.cj.jdbc.Driver");
//	            String url = "jdbc:mysql://localhost:3306/PMQLBH";
//	            String user = "root";
//	            String password = "180504";
//	            conn = DriverManager.getConnection(url, user, password);
//	        } catch (Exception e) {
//	            e.printStackTrace();
//	        }
//	        return conn;
//	    }
//	}
//}
